import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function main() {
  console.log("Seeding database...")

  // Create Applicants
  await prisma.user.upsert({
    where: { email: "applicant1@example.com" },
    update: {},
    create: {
      email: "applicant1@example.com",
      name: "John Doe",
      role: "APPLICANT",
    },
  })

  await prisma.user.upsert({
    where: { email: "applicant2@example.com" },
    update: {},
    create: {
      email: "applicant2@example.com",
      name: "Jane Smith",
      role: "APPLICANT",
    },
  })

  // Create Faculty Mentors
  await prisma.user.upsert({
    where: { email: "faculty.cse@iitrpr.ac.in" },
    update: {},
    create: {
      email: "faculty.cse@iitrpr.ac.in",
      name: "Dr. Amit Kumar",
      role: "FACULTY_MENTOR",
      department: "CSE",
    },
  })

  await prisma.user.upsert({
    where: { email: "faculty.ee@iitrpr.ac.in" },
    update: {},
    create: {
      email: "faculty.ee@iitrpr.ac.in",
      name: "Dr. Priya Sharma",
      role: "FACULTY_MENTOR",
      department: "EE",
    },
  })

  await prisma.user.upsert({
    where: { email: "faculty.me@iitrpr.ac.in" },
    update: {},
    create: {
      email: "faculty.me@iitrpr.ac.in",
      name: "Dr. Rajesh Singh",
      role: "FACULTY_MENTOR",
      department: "ME",
    },
  })

  await prisma.user.upsert({
    where: { email: "faculty.civil@iitrpr.ac.in" },
    update: {},
    create: {
      email: "faculty.civil@iitrpr.ac.in",
      name: "Dr. Neha Gupta",
      role: "FACULTY_MENTOR",
      department: "CIVIL",
    },
  })

  await prisma.user.upsert({
    where: { email: "faculty.physics@iitrpr.ac.in" },
    update: {},
    create: {
      email: "faculty.physics@iitrpr.ac.in",
      name: "Dr. Sunil Verma",
      role: "FACULTY_MENTOR",
      department: "PHYSICS",
    },
  })

  // Create HODs (one per department)
  await prisma.user.upsert({
    where: { email: "hod.cse@iitrpr.ac.in" },
    update: {},
    create: {
      email: "hod.cse@iitrpr.ac.in",
      name: "Prof. Sanjay Gupta",
      role: "HOD",
      department: "CSE",
    },
  })

  await prisma.user.upsert({
    where: { email: "hod.ee@iitrpr.ac.in" },
    update: {},
    create: {
      email: "hod.ee@iitrpr.ac.in",
      name: "Prof. Meera Patel",
      role: "HOD",
      department: "EE",
    },
  })

  await prisma.user.upsert({
    where: { email: "hod.me@iitrpr.ac.in" },
    update: {},
    create: {
      email: "hod.me@iitrpr.ac.in",
      name: "Prof. Vikram Rao",
      role: "HOD",
      department: "ME",
    },
  })

  await prisma.user.upsert({
    where: { email: "hod.civil@iitrpr.ac.in" },
    update: {},
    create: {
      email: "hod.civil@iitrpr.ac.in",
      name: "Prof. Anita Sharma",
      role: "HOD",
      department: "CIVIL",
    },
  })

  await prisma.user.upsert({
    where: { email: "hod.physics@iitrpr.ac.in" },
    update: {},
    create: {
      email: "hod.physics@iitrpr.ac.in",
      name: "Prof. Ramesh Kumar",
      role: "HOD",
      department: "PHYSICS",
    },
  })

  // Create Junior Superintendent
  await prisma.user.upsert({
    where: { email: "js.hostel@iitrpr.ac.in" },
    update: {},
    create: {
      email: "js.hostel@iitrpr.ac.in",
      name: "Mr. Suresh Kumar",
      role: "JUNIOR_SUPERINTENDENT",
    },
  })

  // Create Assistant Registrar
  await prisma.user.upsert({
    where: { email: "ar.academic@iitrpr.ac.in" },
    update: {},
    create: {
      email: "ar.academic@iitrpr.ac.in",
      name: "Mr. Ramesh Verma",
      role: "ASSISTANT_REGISTRAR",
    },
  })

  // Create Chief Warden
  await prisma.user.upsert({
    where: { email: "chief.warden@iitrpr.ac.in" },
    update: {},
    create: {
      email: "chief.warden@iitrpr.ac.in",
      name: "Prof. Anil Sharma",
      role: "CHIEF_WARDEN",
    },
  })

  console.log("Database seeded successfully!")
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
